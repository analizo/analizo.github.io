public class Dog extends Mammal {
  private String _name;
  public Dog(String name) {
    _name = name;
  }
  public String name() {
    return _name;
  }
}
