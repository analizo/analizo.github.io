public Class Polygons{
  public static void main(string args[]){
    Square square = new Square(2);
    Retangle retangle = new Retangle(2,3);
    Triangle triangle = new Triangle(4,7);
  }
}
