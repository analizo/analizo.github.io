public class Square extends Tetragon {
  public int area () { 
    return (width * width); 
  }
}
