#include "lib.h"

int main(int argc, char** argv) {
  say_hello();
  return 0;
}
