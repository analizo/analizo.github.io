#include <stdlib.h>
#include <stdio.h>
int main()
{
	int * x;
	if (x != NULL)
		return 0;
	return 0;
}
