int main(void)
{
  int x;
  int y = x;
}
