int divide(int a)
{
	return (a/0);
}

int main(void)
{
  int x = 5/0;
  divide(4);
  return x;
}

