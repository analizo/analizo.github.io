#include <stdlib.h>
#include <string.h>

int main ()
{
  char *data = NULL;
  int datalen = strlen((char*) data);
  return datalen;
}
