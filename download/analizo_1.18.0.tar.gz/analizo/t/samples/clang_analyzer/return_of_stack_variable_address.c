#define STR_MAX 4096

char* getName() {
  char name[STR_MAX];
  fillInName(name);
  return name;
}

