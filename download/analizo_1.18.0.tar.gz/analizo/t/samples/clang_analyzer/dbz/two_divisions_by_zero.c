int divide(int a)
{
	return (a/0);
}
int main(void)
{
  int x = 5/0;
  return x;
}

