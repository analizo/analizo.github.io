int main(void)
{
  int x = 5/0;
  return x;
}

