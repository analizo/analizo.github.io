int main(void)
{
  int *pointer = 0;
  *pointer++;
}
