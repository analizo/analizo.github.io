# Community

## Getting in touch

Help regarding Analizo usage can be obtained in the [Analizo mailing
list](http://librelist.com/browser/analizo/). To subscribe, send an empty
e-mail to subscribe to `analizo@librelist.com`). You can also browse the [list
archive](http://librelist.com/browser/analizo/) to see whether
your problem was already discussed before or not.

You can also find us at IRC: channel `#analizo` on the [Freenode
network](http://freenode.net/).

## Reporting bugs

Report bugs [at Github](http://github.com/analizo/analizo/issues).

## Contributing

Source code is available [at Github](http://github.com/analizo/analizo).

See the "developer documentation" section at the [Documentation
page](documentation.html).
