<div class='jumbotron'>
  <p>
  Analizo is a free, multi-language, extensible source code analysis and
  visualization toolkit. It supports the extraction and calculation of a fair
  number of source code metrics, generation of dependency graphs, and software
  evolution analysis.
  </p>

  <div class='button-bar'>
  <a class='btn btn-success' href='download.html'>Download</a>
  <a class='btn btn-primary' href='documentation.html'>Documentation</a>
  </div>
</div>

