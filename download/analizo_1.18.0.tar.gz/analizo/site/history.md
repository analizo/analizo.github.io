# History

Analizo was created by Antonio Terceiro as a support tool for his PhD thesis.
Analizo was initially based on [egypt](http://www.gson.org/egypt/) by Andreas
Gustafsson, but currently very little of egypt's code is left.

Analizo has been co-developed by Antonio Terceiro, Joenio Costa, João Miranda
and Paulo Meirelles. The work on Analizo has been supported by the following
organizations:

   * [LES-UFBA](http://les.dcc.ufba.br/)
   * [INES](http://www.ines.org.br/)
   * [CNPQ](http://www.cnpq.br/)
   * [FAPESB](http://www.fapesb.ba.gov.br/)
   * [CCSL-USP](http://ccsl.ime.usp.br/)
   * [Qualipso project](http://www.qualipso.org/)

