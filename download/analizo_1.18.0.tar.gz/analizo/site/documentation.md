# Documentation

## User documentation

* [Installation](installation.html)
* [Manual pages](man/)
* [History](history.html)
* [Frequently Asked Questions](faq.html)

## Developer documentation

* [Development tips](hacking.html)
* [Profiling tips](profiling.html)
