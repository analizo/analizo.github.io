
=head1 Manual pages

The following manual pages are available:

=begin html

<ul>
<li><a href='analizo.html'>analizo</a></li>
<li><a href='analizo-dsm.html'>analizo-dsm</a></li>
<li><a href='analizo-evolution-matrix.html'>analizo-evolution-matrix</a></li>
<li><a href='analizo-graph.html'>analizo-graph</a></li>
<li><a href='analizo-help.html'>analizo-help</a></li>
<li><a href='analizo-metrics.html'>analizo-metrics</a></li>
<li><a href='analizo-metrics-batch.html'>analizo-metrics-batch</a></li>
<li><a href='analizo-metrics-history.html'>analizo-metrics-history</a></li>
<li><a href='analizo-tree-evolution.html'>analizo-tree-evolution</a></li>
</ul>

=end html
