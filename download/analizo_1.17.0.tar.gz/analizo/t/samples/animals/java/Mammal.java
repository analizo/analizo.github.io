public abstract class Mammal extends Animal {
}
