#ifndef _HELLO_H_
#define _HELLO_H_

#include <string>

using namespace std;

class HelloWorld {
  public:
    string message();
};

#endif // _HELLO_H_
