public abstract class Tetragon extends Polygon {     
  public abstract int area ();
}
