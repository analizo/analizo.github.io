void cc1() {
  printf("ok\n");
}
