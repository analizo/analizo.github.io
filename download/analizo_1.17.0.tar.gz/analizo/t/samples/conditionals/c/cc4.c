void cc4() {
  if (something) {
    printf("ok\n");
  } else {
    if (otherthing) {
      if (someotherthing) {
        printf("don't know\n");
      } else {
        printf("me neither\n");
      }
      printf("nope\n");
    }
  }
}
