#include "classes.h"

int main(int argc, char** argv) {
  Class1 c1;
  Class2 c2;
  c1.say();
  c2.say();
  return 0;
}
